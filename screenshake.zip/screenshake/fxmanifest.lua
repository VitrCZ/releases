fx_version 'cerulean'
game 'gta5'


author 'V�tr'
description 'Shakes screen on vehicle acceleration'
version '1.0.0'

lua54 'yes'

client_scripts {
    'config.lua',
    'client.lua'
}

