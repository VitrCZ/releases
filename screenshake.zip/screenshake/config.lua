
Config = {}

-- Increase or decrease the shake strength or duration
Config.ShakeStrength = 1.0
Config.ShakeDuration = 1000 -- in milliseconds so 1000 / 1000 = 1 sec