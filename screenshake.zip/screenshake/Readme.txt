How to use:

1. Extract in your resources folder
2. Add ensure screenshake in your server.cfg (you can also use start screenshake)
3. Enjoy

